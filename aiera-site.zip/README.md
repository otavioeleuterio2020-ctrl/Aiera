# Aiera Beach Club
Site estático (HTML/CSS/JS). Abra index.html ou publique no GitHub Pages.
Configuração (GA4, Search Console, galeria, serviços): bloco <script> no fim do index.html.
